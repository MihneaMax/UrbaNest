// configurare initiala
document.addEventListener('DOMContentLoaded', () => {
    initializeSystem();
    setupFormValidation();
    setupCanvasMap();
    initializeThemeToggle();
    setupVisitorCounter();
    loadStoredMessages();
});

// sistem de management utilizatori
const initializeUserSystem = () => {
    // verificam dacă există deja utilizatori în localStorage
    if (!localStorage.getItem('users')) {
        const initialUsers = [
            {
                username: "admin",
                password: "admin123",
                role: "admin",
                dateCreated: new Date().toISOString()
            },
            {
                username: "agent1",
                password: "test123",
                role: "agent",
                dateCreated: new Date().toISOString()
            }
        ];
        localStorage.setItem('users', JSON.stringify(initialUsers));
    }
};

// crearea interfetei de login
const createLoginInterface = () => {
    const loginSection = document.createElement('div');
    loginSection.className = 'login-section';
    loginSection.innerHTML = `
        <div class="login-container" style="margin: 20px auto; max-width: 300px; padding: 20px; background: white; border-radius: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
            <h3>Autentificare</h3>
            <input type="text" id="username" placeholder="Utilizator" style="width: 100%; padding: 8px; margin: 5px 0; border: 1px solid #ddd; border-radius: 4px;">
            <input type="password" id="password" placeholder="Parolă" style="width: 100%; padding: 8px; margin: 5px 0; border: 1px solid #ddd; border-radius: 4px;">
            <button id="loginBtn" style="width: 100%; padding: 10px; background: #333; color: white; border: none; border-radius: 4px; cursor: pointer; margin-top: 10px;">Autentificare</button>
            <div id="loginStatus" style="margin-top: 10px; text-align: center;"></div>
        </div>
    `;

    document.querySelector('.contact-form').before(loginSection);

    document.getElementById('loginBtn').addEventListener('click', () => {
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        if (handleLogin(username, password)) {
            document.getElementById('loginStatus').innerHTML = `
                <p style="color: green;">Autentificat ca ${username}</p>
                <button onclick="handleLogout()" style="padding: 5px 10px; background: #ff4444; color: white; border: none; border-radius: 4px; cursor: pointer; margin-top: 5px;">Deconectare</button>
            `;
            if (localStorage.getItem('userRole') === 'admin') {
                document.querySelector('.admin-section').style.display = 'block';
                updateUsersList();
            }
        } else {
            alert('Credențiale invalide!');
        }
    });
};

// interfata de administrare
const createAdminInterface = () => {
    const adminSection = document.createElement('div');
    adminSection.className = 'admin-section';
    adminSection.style.display = 'none';

    adminSection.innerHTML = `
        <div style="margin: 20px auto; max-width: 800px; padding: 20px; background: white; border-radius: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
            <h2>Panou Administrare Utilizatori</h2>
            
            <div style="margin: 20px 0;">
                <h3>Adaugă Utilizator Nou</h3>
                <form id="addUserForm" style="display: flex; flex-direction: column; gap: 10px;">
                    <input type="text" id="newUsername" placeholder="Nume utilizator" required>
                    <input type="password" id="newPassword" placeholder="Parolă" required>
                    <select id="newRole" required>
                        <option value="agent">Agent</option>
                        <option value="admin">Administrator</option>
                    </select>
                    <button type="submit" style="background: #4CAF50; color: white; padding: 10px; border: none; border-radius: 5px; cursor: pointer;">
                        Adaugă Utilizator
                    </button>
                </form>
            </div>
            
            <div style="margin: 20px 0;">
                <h3>Listă Utilizatori</h3>
                <div id="usersList" style="margin-top: 10px;"></div>
            </div>
        </div>
    `;

    document.querySelector('.contact-form').before(adminSection);
    return adminSection;
};

// functii pentru managementul utilizatorilor
const addNewUser = (e) => {
    e.preventDefault();

    const username = document.getElementById('newUsername').value;
    const password = document.getElementById('newPassword').value;
    const role = document.getElementById('newRole').value;

    const users = JSON.parse(localStorage.getItem('users'));
    if (users.some(user => user.username === username)) {
        alert('Acest nume de utilizator există deja!');
        return;
    }

    users.push({
        username,
        password,
        role,
        dateCreated: new Date().toISOString()
    });

    localStorage.setItem('users', JSON.stringify(users));
    e.target.reset();
    updateUsersList();
    alert('Utilizator adăugat cu succes!');
};

const updateUsersList = () => {
    const usersList = document.getElementById('usersList');
    const users = JSON.parse(localStorage.getItem('users'));

    usersList.innerHTML = `
        <table style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr>
                    <th style="text-align: left; padding: 8px; border-bottom: 2px solid #ddd;">Utilizator</th>
                    <th style="text-align: left; padding: 8px; border-bottom: 2px solid #ddd;">Rol</th>
                    <th style="text-align: left; padding: 8px; border-bottom: 2px solid #ddd;">Data creării</th>
                    <th style="text-align: left; padding: 8px; border-bottom: 2px solid #ddd;">Acțiuni</th>
                </tr>
            </thead>
            <tbody>
                ${users.map(user => `
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">${user.username}</td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">${user.role}</td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">
                            ${new Date(user.dateCreated).toLocaleDateString()}
                        </td>
                        <td style="padding: 8px; border-bottom: 1px solid #ddd;">
                            ${user.username !== 'admin' ? `
                                <button onclick="deleteUser('${user.username}')"
                                    style="background: #ff4444; color: white; border: none; padding: 5px 10px; border-radius: 3px; cursor: pointer;">
                                    Șterge
                                </button>
                            ` : ''}
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
};

const deleteUser = (username) => {
    if (confirm(`Ești sigur că vrei să ștergi utilizatorul ${username}?`)) {
        let users = JSON.parse(localStorage.getItem('users'));
        users = users.filter(user => user.username !== username);
        localStorage.setItem('users', JSON.stringify(users));
        updateUsersList();
    }
};

const handleLogin = (username, password) => {
    const users = JSON.parse(localStorage.getItem('users'));
    const user = users.find(u => u.username === username && u.password === password);

    if (user) {
        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('username', username);
        localStorage.setItem('userRole', user.role);
        return true;
    }
    return false;
};

const handleLogout = () => {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('username');
    localStorage.removeItem('userRole');
    location.reload();
};

// initializare sistem
const initializeSystem = () => {
    initializeUserSystem();
    createLoginInterface();
    const adminSection = createAdminInterface();

    document.getElementById('addUserForm').addEventListener('submit', addNewUser);

    if (localStorage.getItem('userRole') === 'admin') {
        adminSection.style.display = 'block';
        updateUsersList();
    }
};

// validare formular contact
const setupFormValidation = () => {
    const form = document.getElementById('contactForm');
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    const phoneInput = document.createElement('input');
    phoneInput.type = 'tel';
    phoneInput.name = 'telefon';
    phoneInput.placeholder = 'Telefon (format: 07XX-XXX-XXX)';
    phoneInput.style.width = '100%';
    phoneInput.style.padding = '10px';
    phoneInput.style.margin = '10px 0';
    phoneInput.style.border = '1px solid #ccc';
    phoneInput.style.borderRadius = '10px';
    phoneInput.style.boxSizing = 'border-box';

    form.querySelector('input[name="email"]').after(phoneInput);

    const phoneRegex = /^07\d{2}-\d{3}-\d{3}$/;

    form.addEventListener('submit', (e) => {
        e.preventDefault();

        const email = form.querySelector('input[name="email"]').value;
        const phone = phoneInput.value;
        const message = form.querySelector('textarea[name="mesaj"]').value;

        if (!emailRegex.test(email)) {
            showError('Email invalid!');
            return;
        }

        if (!phoneRegex.test(phone)) {
            showError('Număr de telefon invalid! Folosiți formatul: 07XX-XXX-XXX');
            return;
        }

        saveMessage({
            email,
            phone,
            message,
            date: new Date().toISOString()
        });

        showSuccess();
        form.reset();
    });
};

// harta Canvas
const setupCanvasMap = () => {
    const canvas = document.createElement('canvas');

    // setam canvas ul sa ocupe 80% din latimea paginii
    canvas.style.width = '80%';
    canvas.style.maxWidth = '1200px';
    canvas.style.height = 'auto';

    canvas.width = 1200;
    canvas.height = 600;

    canvas.style.margin = '20px auto';
    canvas.style.display = 'block';
    canvas.style.border = '1px solid #ccc';
    canvas.style.borderRadius = '10px';
    canvas.style.boxShadow = '0 2px 4px rgba(0,0,0,0.1)';

    document.querySelector('.contact-form').after(canvas);

    const ctx = canvas.getContext('2d');

    // coordonatele pentru Unirii(alta idee n-am avut)
    const location = {
        lat: 44.4268,
        lng: 26.1025,
        name: 'Urban Nest București'
    };

    const drawMap = () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // fundal harta
        ctx.fillStyle = '#e8f4f8';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // grid
        ctx.strokeStyle = '#ccc';
        ctx.lineWidth = 0.5;
        for (let i = 0; i < canvas.width; i += 50) {
            ctx.beginPath();
            ctx.moveTo(i, 0);
            ctx.lineTo(i, canvas.height);
            ctx.stroke();
        }
        for (let i = 0; i < canvas.height; i += 50) {
            ctx.beginPath();
            ctx.moveTo(0, i);
            ctx.lineTo(canvas.width, i);
            ctx.stroke();
        }

        // marker locatie
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;

        ctx.beginPath();
        ctx.fillStyle = '#FF4444';
        ctx.moveTo(centerX, centerY);
        ctx.arc(centerX, centerY - 15, 15, 0, Math.PI * 2);
        ctx.fill();

        ctx.beginPath();
        ctx.fillStyle = 'rgba(0,0,0,0.2)';
        ctx.moveTo(centerX - 10, centerY);
        ctx.lineTo(centerX + 10, centerY);
        ctx.lineTo(centerX, centerY + 20);
        ctx.fill();

        // text
        ctx.fillStyle = '#333';
        ctx.font = 'bold 24px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(location.name, centerX, centerY + 40);

        ctx.font = '16px Arial';
        ctx.fillText('Click pe hartă pentru a deschide în Google Maps', centerX, centerY + 70);
    };

    drawMap();

    canvas.addEventListener('click', () => {
        const mapsUrl = `https://www.google.com/maps?q=${location.lat},${location.lng}`;
        window.open(mapsUrl, '_blank');
    });

    canvas.addEventListener('mousemove', (e) => {
        const rect = canvas.getBoundingClientRect();
        const scaleX = canvas.width / rect.width;
        const scaleY = canvas.height / rect.height;

        const x = (e.clientX - rect.left) * scaleX;
        const y = (e.clientY - rect.top) * scaleY;

        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;

        if (Math.hypot(x - centerX, y - (centerY - 15)) < 15 * scaleX) {
            canvas.style.cursor = 'pointer';
        } else {
            canvas.style.cursor = 'default';
        }
    });
};


// functii utilitare
const showError = (message) => {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.style.color = 'red';
    errorDiv.style.margin = '10px 0';
    errorDiv.textContent = message;

    const form = document.getElementById('contactForm');
    form.appendChild(errorDiv);

    setTimeout(() => {
        errorDiv.remove();
    }, 3000);
};

const showSuccess = () => {
    const confirmationMessage = document.getElementById('confirmation-message');
    confirmationMessage.style.display = 'block';

    setTimeout(() => {
        confirmationMessage.style.display = 'none';
    }, 2000);
};

const saveMessage = (message) => {
    const messages = JSON.parse(localStorage.getItem('messages') || '[]');
    messages.push(message);
    localStorage.setItem('messages', JSON.stringify(messages));
};

// afisare mesaje salvate pentru agenti autentificati
const loadStoredMessages = () => {
    if (localStorage.getItem('isLoggedIn') === 'true') {
        const messages = JSON.parse(localStorage.getItem('messages') || '[]');
        const messagesContainer = document.createElement('div');
        messagesContainer.className = 'stored-messages';
        messagesContainer.innerHTML = `
            <h3>Mesaje primite</h3>
            ${messages.map(msg => `
                <div class="message-card">
                    <p><strong>Email:</strong> ${msg.email}</p>
                    <p><strong>Telefon:</strong> ${msg.phone}</p>
                    <p><strong>Mesaj:</strong> ${msg.message}</p>
                    <p><strong>Data:</strong> ${new Date(msg.date).toLocaleString()}</p>
                </div>
            `).join('')}
        `;
        document.querySelector('.contact-form').after(messagesContainer);
    }
};

// schimbare tema aleatorie
const initializeThemeToggle = () => {
    const colors = ['#f0f0f0', '#e8f4f8', '#f8e8e8', '#e8f8e8'];
    const button = document.createElement('button');
    button.textContent = 'Schimbă Tema';
    button.style.margin = '20px';
    button.style.padding = '10px 20px';
    button.style.borderRadius = '5px';
    button.style.border = 'none';
    button.style.backgroundColor = '#333';
    button.style.color = 'white';
    button.style.cursor = 'pointer';

    document.querySelector('header').after(button);

    button.addEventListener('click', () => {
        const randomColor = colors[Math.floor(Math.random() * colors.length)];
        document.body.style.backgroundColor = randomColor;
    });
};